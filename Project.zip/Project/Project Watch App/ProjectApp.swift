//
//  ProjectApp.swift
//  Project Watch App
//
//  Created by Anirudh Anil on 2023-03-29.
//

import SwiftUI

@main
struct Project_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
